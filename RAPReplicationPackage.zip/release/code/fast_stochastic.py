import sys
sys.path.insert(0, ".")
import numpy as np
import pandas as pd
from scipy.special import roots_hermite
from params import rap_monthly_payment

def rap_annual_payment_vec(agi, dependents=0):
    agi = np.clip(np.asarray(agi, dtype=float), 0, None)
    rate = np.select(
        [agi <= 10000, agi <= 20000, agi <= 30000, agi <= 40000, agi <= 50000,
         agi <= 60000, agi <= 70000, agi <= 80000, agi <= 90000, agi <= 100000],
        [0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09],
        default=0.10,
    )
    base_monthly = np.where(agi <= 10000, 10.0, agi * rate / 12.0)
    payment_monthly = np.maximum(base_monthly - 50 * dependents, 10.0)
    return payment_monthly * 12.0

chk = rap_annual_payment_vec(np.array([45000.0]))[0]
assert abs(chk - 150.0 * 12) < 0.01
print(f"Checkpoint OK: RAP(45000) = ${chk/12:.2f}/mo")

# ---- Gauss-Hermite quadrature nodes/weights for E[f(target + sigma*eps)], eps~N(0,1) ----
N_NODES = 40
_nodes, _weights = roots_hermite(N_NODES)  # for integral against e^{-x^2}
_nodes = _nodes * np.sqrt(2)               # rescale: eps = sqrt(2)*u
_weights = _weights / np.sqrt(np.pi)       # normalize

def expected_payment_vec(targets, sigma):
    """targets: 1D array. Returns E[payment(target + sigma*eps)] for each target,
    via Gauss-Hermite quadrature (exact for polynomials, very accurate for this
    piecewise-linear-with-jumps integrand given enough nodes)."""
    targets = np.asarray(targets, dtype=float)
    if sigma == 0:
        return rap_annual_payment_vec(targets)
    # shape: (n_targets, n_nodes)
    grid = targets[:, None] + sigma * _nodes[None, :]
    pay = rap_annual_payment_vec(grid.ravel()).reshape(grid.shape)
    return pay @ _weights

def expected_net_income_vec(targets, sigma):
    return targets - expected_payment_vec(targets, sigma)

def optimal_target_fast(threshold, sigma, search_window=2500, step=5):
    candidates = np.arange(threshold - search_window, threshold + 1, step)
    net_income = expected_net_income_vec(candidates, sigma)
    i = np.argmax(net_income)
    return candidates[i], net_income[i]

if __name__ == "__main__":
    # quick validation against the (slow) Monte Carlo results already on file
    for T, s, expect_buf in [(50000, 0, 0), (50000, 100, 120), (50000, 5000, 0), (100000, 0, 0)]:
        t_star, _ = optimal_target_fast(T, s)
        buf = T - t_star
        print(f"T=${T:,} sigma=${s}: buffer=${buf} (MC gave ~${expect_buf})")
